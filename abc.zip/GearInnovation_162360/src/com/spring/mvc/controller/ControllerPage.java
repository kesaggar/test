package com.spring.mvc.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.hibernate.QueryException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.spring.mvc.exception.MyQueryException;
import com.spring.mvc.model.QueryMaster;
import com.spring.mvc.service.IqueryService;
@Controller
public class ControllerPage {
	@Autowired
	IqueryService qSer;
	@RequestMapping("/HomePage")
	public String showHomePage(Model model)
	{
		model.addAttribute("QueryMaster",new QueryMaster());
		String view="HomePage";
		return view;
	}
	@RequestMapping("/fetchDataPage")
	public String fetchQueryData(@Valid@ModelAttribute("QueryMaster") QueryMaster qmaster,BindingResult bindingResult,Model model,HttpServletRequest req) throws MyQueryException
	{
		QueryMaster querymaster=qSer.getQueryData(qmaster.getQueryId());
		
		if(querymaster!=null)
		{
		String view="queryPage";
		model.addAttribute("message","Gear Technical Forum");
		model.addAttribute("message2","Answer the query");
		List<String> student=new ArrayList<>();
		student.add("Uma");
		student.add("Rahul");
		student.add("kavita");
		student.add("hema");
		model.addAttribute("QueryMaster",new QueryMaster());
		ServletContext context1=req.getServletContext();
		context1.setAttribute("student", student);
		ServletContext context=req.getServletContext();
		context.setAttribute("queryData", querymaster);
		return view;
	}
		else
		{
			throw new MyQueryException("Query Not Found, Wrong Query Id "+" "+qmaster.getQueryId());
		}
		
		}
	
	@RequestMapping("/setDataPage")
	public String showHomePage(@Valid@ModelAttribute("QueryMaster") QueryMaster qmaster,BindingResult bindingResult,Model model,HttpServletRequest req)
	{
		String view="successPage";
		qSer.setqueryData(qmaster);
		model.addAttribute("QueryMaster",new QueryMaster());
		ServletContext context=req.getServletContext();
		context.setAttribute("message",qmaster );
		return view;
	}

}

