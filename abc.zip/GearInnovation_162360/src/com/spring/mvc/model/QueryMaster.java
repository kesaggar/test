package com.spring.mvc.model;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class QueryMaster {
	@Id
int queryId;
	String technology;
	String queryRaisedBy;
	String query;
	String solutions;
	String solutionBy;
	public QueryMaster() {
		super();
	}
	public int getQueryId() {
		return queryId;
	}
	public void setQueryId(int queryId) {
		this.queryId = queryId;
	}
	public String getTechnology() {
		return technology;
	}
	public void setTechnology(String technology) {
		this.technology = technology;
	}
	public String getQueryRaisedBy() {
		return queryRaisedBy;
	}
	public void setQueryRaisedBy(String queryRaisedBy) {
		this.queryRaisedBy = queryRaisedBy;
	}
	public String getQuery() {
		return query;
	}
	public void setQuery(String query) {
		this.query = query;
	}
	public String getSolutions() {
		return solutions;
	}
	public void setSolutions(String solutions) {
		this.solutions = solutions;
	}
	public String getSolutionBy() {
		return solutionBy;
	}
	public void setSolutionBy(String solutionBy) {
		this.solutionBy = solutionBy;
	}
	@Override
	public String toString() {
		return "QueryMaster [queryId=" + queryId + ", technology=" + technology + ", queryRaisedBy=" + queryRaisedBy
				+ ", query=" + query + ", solutions=" + solutions + ", solutionBy=" + solutionBy + "]";
	}
	public QueryMaster(int queryId, String technology, String queryRaisedBy, String query, String solutions,
			String solutionGivenBy) {
		super();
		this.queryId = queryId;
		this.technology = technology;
		this.queryRaisedBy = queryRaisedBy;
		this.query = query;
		this.solutions = solutions;
		this.solutionBy = solutionBy;
	}
	
	
}
