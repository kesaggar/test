package com.spring.mvc.service;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.spring.mvc.dao.IQueryDao;
import com.spring.mvc.model.QueryMaster;
@Service
@Transactional
public class QueryService implements IqueryService{
@Autowired
IQueryDao qDao;
	@Override
	public QueryMaster getQueryData(int id) {
		return qDao.getQueryData(id);
	}
	@Override
	public void setqueryData(QueryMaster qmaster) {
		qDao.setqueryData(qmaster);
		
	}

}
