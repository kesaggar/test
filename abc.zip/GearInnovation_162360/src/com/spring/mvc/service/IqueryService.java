package com.spring.mvc.service;

import com.spring.mvc.model.QueryMaster;

public interface IqueryService {
QueryMaster getQueryData(int id);
void setqueryData(QueryMaster qmaster);
}
