package com.spring.mvc.exception;

public class MyQueryException extends Exception{

	public MyQueryException(String message) {
		super(message);
	}
}
