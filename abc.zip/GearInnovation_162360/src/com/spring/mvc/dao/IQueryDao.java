package com.spring.mvc.dao;

import com.spring.mvc.model.QueryMaster;

public interface IQueryDao {
	QueryMaster getQueryData(int id);
	void setqueryData(QueryMaster qmaster);
}
