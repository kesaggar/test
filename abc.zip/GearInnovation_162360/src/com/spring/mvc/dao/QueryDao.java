package com.spring.mvc.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;

import com.spring.mvc.model.QueryMaster;
@Repository
public class QueryDao implements IQueryDao{
@PersistenceContext
private EntityManager manager;
	@Override
	public QueryMaster getQueryData(int id) {
		QueryMaster qmaster=manager.find(QueryMaster.class, id);
		return qmaster;
	}
	@Override
	public void setqueryData(QueryMaster qmaster) {
		QueryMaster queryMas=new QueryMaster();
		QueryMaster myQueryMaster=	manager.find(QueryMaster.class,qmaster.getQueryId());
		myQueryMaster.setSolutions(qmaster.getSolutions());
		myQueryMaster.setSolutionBy(qmaster.getSolutionBy());
		manager.persist(myQueryMaster);
		
	}

}
